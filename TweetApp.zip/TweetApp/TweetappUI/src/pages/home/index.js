import Home from "./home.container";

export default Home;