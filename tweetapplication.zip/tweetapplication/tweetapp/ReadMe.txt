DB name - Tweetapp
Tables - user, tweettable

1. user table contains 5 fields - firstname, lastname, gender, emailid, dob and password.
2. tweettable contains 2 fields - username and tweet.