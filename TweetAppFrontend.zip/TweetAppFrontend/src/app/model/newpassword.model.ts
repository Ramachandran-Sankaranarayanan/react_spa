export class NewPassword{
    newPassword :  string;
    constructor(newPassword){
        this.newPassword = newPassword;
    }
}